ANTIGRAVITY LOCAL SETUP PACK
================================

WHAT THIS PACKAGE DOES

This package installs the tested Antigravity Local setup selected for your Mac before payment.
It prepares a private runtime, downloads the matching local model, connects Antigravity to it,
and runs a real response test during setup.

HOW TO INSTALL

1. Keep this ZIP as your purchase copy.
2. Double-click AntigravityLocalSetup.pkg.
3. Follow the normal macOS Installer prompts.
4. After the package window finishes, the model setup can continue in the background.
5. Keep your Mac awake and connected to the internet while the runtime and model are downloaded.

The first setup can take time because the model files are downloaded after the package is installed.
If the setup was interrupted, running the .pkg again is safe.

YOU DO NOT NEED

- Terminal commands
- Python or pip
- Manual Ollama commands
- API keys
- Manual model configuration

INSTALLATION LOGS

If support asks for installation details, the package writes logs under:

~/Library/Logs/AntigravityLocal/

Do not edit the private runtime files unless support specifically asks you to.
