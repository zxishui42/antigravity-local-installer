ANTIGRAVITY LOCAL SETUP PACK
================================

WHAT THIS PACKAGE DOES

This package installs the tested Antigravity Local setup selected for your computer before payment.
It prepares the required local runtime, downloads the matching local model, connects Antigravity to it,
and runs an installation test.

HOW TO INSTALL

1. Keep this ZIP as your purchase copy.
2. Double-click AntigravityLocalSetup.exe.
3. Choose the local drive where you want the model files stored.
4. Click Install.
5. Leave the installer open while the runtime and model are downloaded.
6. When installation finishes, click Test installation.

The model download can take time depending on its size and your network connection.
Re-running the installer is safe if the first attempt is interrupted.

YOU DO NOT NEED

- PowerShell or Command Prompt
- Python or pip
- Manual Ollama commands
- API keys
- Manual model configuration

AFTER INSTALLATION

Windows creates an Antigravity Installation Test shortcut on your desktop.
Run it once after installation. A pass means Antigravity successfully started the local model
and received a response.

If installation stops, use Copy details in the installer and send that log to support.
Do not try to repair the private runtime manually.
